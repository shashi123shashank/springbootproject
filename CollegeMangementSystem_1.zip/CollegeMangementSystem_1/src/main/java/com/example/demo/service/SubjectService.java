package com.example.demo.service;

import java.util.List;
import com.example.demo.entity.Subject;
import com.example.demo.error.StudentNotFoundException;
import com.example.demo.error.SubjectNotFoundException;
import com.example.demo.error.TeacherNotFoundException;

public interface SubjectService {

	Subject addSubject(Subject subject);

	List<Subject> getAllSubject();

	void deleteById(Integer subid) throws SubjectNotFoundException;

	Subject updateSubject(Integer subid, Subject subject) throws SubjectNotFoundException;

	Subject assignStudentToSubject(Integer subid, Integer stuid) throws SubjectNotFoundException, StudentNotFoundException;

	Subject assignTeacherToSubject(Integer subid, Integer tid) throws TeacherNotFoundException, SubjectNotFoundException;
	
	Subject findById(Integer subid) throws SubjectNotFoundException;

	Subject findBySubjectName(String subjectName) throws SubjectNotFoundException;

}