package com.example.demo.controller;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;
import com.example.demo.repository.StudentRepository;
import com.example.demo.service.StudentService;

@RestController
public class StudentController {
	
	 @Autowired
	 private StudentService studentService;
	 
	 @Autowired
	 private StudentRepository studentRepository;
	 
	 @PostMapping("/student")
	 public ResponseEntity<Student> addStudent( @Valid @RequestBody Student student ) {
		 
		Student stu = studentService.addStudent(student) ;	
		
		return new ResponseEntity<Student>(stu, HttpStatus.CREATED);
	 }
	 
	 
	 @GetMapping("/student")
	 public List<Student>getAllStudent() {
		 
		return studentService.getAllStudent();	 
	 }
	 
	 
	 @DeleteMapping("/student/{stuid}")
	 public String deleteById(@PathVariable("stuid") Integer stuid) throws StudentNotFoundException{
		 studentService.deleteById(stuid);
		 
		 return "Record Deleted Sucessfully";	 
	 }
	 
	 
	 @PutMapping("/student/{stuid}")
	 public Student updateStudent(@PathVariable("stuid")Integer stuid, @RequestBody Student student) throws StudentNotFoundException {
		 
		return studentService.updateStudent(stuid, student);	 
	 }
	 
	 
	 @GetMapping("/student/{stuid}")
	 public Student findById(@PathVariable("stuid")Integer stuid) throws StudentNotFoundException {
		 
		return studentService.findById(stuid);	 
	 }
	 
	 
	 @GetMapping("/studentname/{name}")
	 public Student findByStudentName(@PathVariable("name")String studentName) throws StudentNotFoundException {
		 
		return studentService.findByStudentName(studentName);
	 }
	
	 
	 @GetMapping("/studenttotalfees")
	 public float studenttotalfees() {
		 
		 return studentRepository.totalfees();
	 }
	 
}