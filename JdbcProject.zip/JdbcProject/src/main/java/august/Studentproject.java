package august;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Studentproject {
private static Connection myconn; 
private static Statement st;
private static ResultSet rs;
public static void displayStudents() throws SQLException {
	myconn=JdbscConnections.getConnection();
	st=myconn.createStatement();
	String sel="select * from student";
	rs=st.executeQuery(sel);
	
	System.out.println("sid\tsname\tsphoneno\tsfee\tsaderss\tsroom");
	  
	  while(rs.next()) {
		  int sn=rs.getInt(1);// or rs.getInt("sid");
		  String sname=rs.getString(2);//or rs.getString("sname");
		  String sph=rs.getString(3); //or rs.getInt"sphoneno");
		  float fs=rs.getFloat(4); //rs.getFloat("sfees");
		  String ad=rs.getString(5);//rs.getSting("saddress");
		  int rm=rs.getInt(6);
		  System.out.println(sn+"\t"+sname+  "\t"+sph+  "\t"+fs+  "\t"+ad+"\t "+rm);
	  }
}

public static void addStudents() throws SQLException {
	myconn=JdbscConnections.getConnection();
	st=myconn.createStatement();
	
	int sid,rm;
	String sn,sph,ad;
	float fs;
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter student name");
	sn=sc.next();
	System.out.println("Enter student phoneno");
	sph=sc.next();
	System.out.println("Enter student address");
	ad=sc.next();
	System.out.println("Enter Student id");
	sid=sc.nextInt();
	System.out.println("Enter Student roomno");
	rm=sc.nextInt();
	System.out.println("Enter student fees");
	fs=sc.nextFloat();
	//check record exists
	String sel="select * from student where sid="+sid;
	rs=st.executeQuery(sel);
	if(rs.next()){
		System.out.println(sid+" already exists");
	}else {
		
	String ins="insert into student values("+sid+",'"+sn+"',   "  +sph+","+fs+ ","+ad+", "+rm+")";
	System.out.println(ins);
	int rval=st.executeUpdate(ins);//for insert , update and delete use exceuteUpdate
	if(rval>0) {
		System.out.println("Record is added");
	}
	else {
		System.out.println("Error Occurred");
	}
	}
}
public static void deleteStudent() throws SQLException {
	myconn=JdbscConnections.getConnection();
	st=myconn.createStatement();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter sid to delete record");
	int stdid=sc.nextInt();
  String sel="select * from student where sid="+stdid;
  rs=st.executeQuery(sel);
  if(rs.next()) { //if this statement is true means record exists
	  String del="delete from student where sid="+stdid;
	  int retval=st.executeUpdate(del);
	  if(retval>0) {
		  System.out.println("Record is deleted");
	  }else {
		  System.out.println("Error!!!! occurred");
	  }
  }else {
	  System.out.println(stdid+" not exixts");
  }
	
}

public static void updateStudent() throws SQLException {
	myconn=JdbscConnections.getConnection();
	st=myconn.createStatement();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter name to be changed");
	String n=sc.next();
	System.out.println("Enter student id");
	int stid=sc.nextInt();
	
	//check id exists for updating record
	
	String sel="select * from student where sid="+stid;
	rs=st.executeQuery(sel);
	if(rs.next()) { //update
		String upd="update student set sname='"+n+"' where sid="+stid;
		int retval=st.executeUpdate(upd);
		if(retval>0) {
			System.out.println("Student changed successfully");
		}else {
			System.out.println("Error!!!!");
		}
	}else {
		System.out.println(stid+" not exists for updating record");
	}
	
}
	
}